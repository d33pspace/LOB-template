def process_and_save_xml(input_filename):
    try:
        with open(input_filename, 'r') as infile:
            file_counter = 1
            while True:
                # Read two lines at a time
                first_line = infile.readline()
                second_line = infile.readline()

                # Break if we reach the end of the file
                if not first_line or not second_line:
                    break

                # Find the position of '<?xml' in the first line and '</xml>' in the second line
                start_index = first_line.find('<?xml')
                end_index = second_line.find('</v1:MDMGeneral>')

                # Check if both '<?xml' and '</xml>' are found
                if start_index != -1 and end_index != -1:
                    # Extract the substrings starting from '<?xml' and ending at '</xml>'
                    first_part = first_line[start_index:]
                    second_part = second_line[:end_index + len('</v1:MDMGeneral>')]

                    # Concatenate the two parts
                    concatenated_string = first_part + second_part

                    # Generate output filename with sequence number
                    output_filename = f'output_{file_counter}.xml'
                    file_counter += 1

                    # Save the concatenated string to the output file
                    with open(output_filename, 'w') as outfile:
                        outfile.write(concatenated_string + '\n')

                    print(f"Processed XML string has been saved to {output_filename}")

    except Exception as e:
        print(f"An error occurred: {str(e)}")

# Specify the input filename
input_filename = 'message.input'

# Call the function to process and save the XML strings
process_and_save_xml(input_filename)
